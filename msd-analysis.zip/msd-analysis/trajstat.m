function [traj] = trajstat(data)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
effectiveThresh = 5;
interval = 2;

data(all(data==0,2),:)=[];
effdata = tabulate(data(:,1));
effdata(effdata(:,2)<effectiveThresh,:) = [];
tracks = cell(size(effdata,1),1);
trajStat = -ones(size(effdata,1),4);
for i = 1:size(effdata,1)
    tracks{i,1} = data(data(:,1)==effdata(i,1),:);
    displacement = sqrt(power(tracks{i,1}(end,3)-tracks{i,1}(1,3),2)+power(tracks{i,1}(end,4)-tracks{i,1}(1,4),2));
    distance = 0;
    for ii = 2:size(tracks{i,1},1)
        distance = distance+sqrt(power(tracks{i,1}(ii,3)-tracks{i,1}(ii-1,3),2)+power(tracks{i,1}(ii,4)-tracks{i,1}(ii-1,4),2));
    end
    trajStat(i,1) = tracks{i,1}(1,1);
    trajStat(i,2) = displacement;
    trajStat(i,3) = distance;
    trajStat(i,4) = interval*(tracks{i,1}(end,2)-tracks{i,1}(1,2));
end

traj = -ones(1,4);
traj(1) = mean(trajStat(:,2));
traj(2) = mean(trajStat(:,3));
traj(3) = mean(trajStat(:,4));
traj(4) = length(tracks);



end

