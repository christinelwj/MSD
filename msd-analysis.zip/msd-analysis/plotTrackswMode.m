function [] = plotTrackswMode(confinedParticle, brownianParticle, directedParticle, tracks, pixel)


for i = 1:length(confinedParticle)
  
    particleTrack = tracks{confinedParticle(i)};
    x = particleTrack(:,2)/pixel;
    y = particleTrack(:,3)/pixel;
    plot(x,y,'g')
    hold on
    
end

for i = 1:length(brownianParticle)
    
    particleTrack = tracks{brownianParticle(i)};
    x = particleTrack(:,2)/pixel;
    y = particleTrack(:,3)/pixel;
    plot(x,y, 'b')
    hold on
    
end


for i = 1:length(directedParticle)
    
    particleTrack = tracks{directedParticle(i)};
    x = particleTrack(:,2)/pixel;
    y = particleTrack(:,3)/pixel;
    plot(x,y,'r')
    hold on
    
end
% add by boyou
xlabel('x(pixel)')
ylabel('y(pixel)')
title('Confined motion(g),Directed(r),Brownian(b)')
%axis([0,1412,0,1412])
set(gca,'ydir','reverse')
% plot(posCell(:,1),posCell(:,2),'w')