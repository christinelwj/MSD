function percentage = plotpercentage(coords_x_org1,confinedParticle, brownianParticle, directedParticle)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
percentage = zeros(1,3);

percentage(1) = size(confinedParticle,1)/size(coords_x_org1,1);
percentage(2) = size(directedParticle,1)/size(coords_x_org1,1);
percentage(3) = size(brownianParticle,1)/size(coords_x_org1,1);

hold on
h=bar(1,percentage(1));
set(h,'FaceColor','g');
h=bar(2,percentage(2));
set(h,'FaceColor','r');
h=bar(3,percentage(3));
set(h,'FaceColor','b');
ylabel('percentage')
set(gca,'xtick',[1 2 3]); 
set(gca,'xticklabel',{'confined','directed','brownian'});
hold off
end

