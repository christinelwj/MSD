function [data] = loadxml(file)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
data = [0,0,0,0];
f = parseXML(file);
for fi = 1:(length(f.Children(4).Children)-1)/2
    for fii = 1:(length(f.Children(4).Children(2*fi).Children)-1)/2
       data = [data;str2double(f.Children(4).Children(2*fi).Attributes.Value),str2double(f.Children(4).Children(2*fi).Children(2*fii).Attributes(3).Value),str2double(f.Children(4).Children(2*fi).Children(2*fii).Attributes(5).Value),str2double(f.Children(4).Children(2*fi).Children(2*fii).Attributes(6).Value)]; 
    end
end
data(1,:) = [];
end

