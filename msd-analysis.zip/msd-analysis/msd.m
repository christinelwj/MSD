function [percentage] = msd(data,newFolder)
clip_factor = 0.75;
%pixel = 0.11;
pixel = 0.11;
interval = 2;
effectiveThresh = 5; %frame

data(all(data==0,2),:)=[];
effdata = tabulate(data(:,1));
effdata(effdata(:,2)<effectiveThresh,:) = [];

datawTime = data;
datawTime(:,2) = datawTime(:,2)*interval;

trackswNum = cell(size(effdata,1),1);
tracks = cell(size(effdata,1),1);
for i = 1:size(effdata,1)
    trackswNum{i,1} = datawTime(datawTime(:,1)==effdata(i,1),:);
    tracks{i,1} = trackswNum{i,1}(:,2:4);
end


% Simulation Parameters (Mean-sq-displacement)
SPACE_UNITS = 'um';
TIME_UNITS = 's';
N_DIM = 2; % 2D

%put in tracks
ma = msdanalyzer(N_DIM, SPACE_UNITS, TIME_UNITS);
ma = ma.addAll(tracks);

%compute Mean-square-displacement
ma = ma.computeMSD;

%plot Mean-square-displacement for each of the trajectories
figure
ma.plotMSD;
title('MSD')
saveas(gca,strcat(newFolder,'\',newFolder(5:end),'MSD'));

%plot tracks
figure
ma.plotTracks;
ma.labelPlotTracks;
title('Trajectory')
saveas(gca,strcat(newFolder,'\',newFolder(5:end),'Trajectory'));

%analyzeTracks(trackswNum,newFolder);

v = ma.getVelocities;
vAll = [];
for vi = 1:length(v)
    v{vi,1}(:,4) = sqrt(power(v{vi,1}(:,2),2)+power(v{vi,1}(:,3),2));
    vAll = [vAll;v{vi,1}(:,4)];
end
figure
histogram(vAll);
title('velocity distribution');
saveas(gca,strcat(newFolder,'\',newFolder(5:end),'VelocityDistribution'));
close;



ma = fitLogLogMSD(ma, clip_factor);


%% Classify tracks into Brownian, Directed & Confined motion based on the MSD curve

tracks = ma.tracks;

%Count number of confined particles
confinedParticle = find(and(ma.loglogfit.alpha<0.9, ma.loglogfit.r2fit>0.8));
%confinedParticle = find(ma.loglogfit.alpha<0.9);
numConfined = length(confinedParticle);

%Count number of directed particles
directedParticle = find(and(ma.loglogfit.alpha>1.2, ma.loglogfit.r2fit>0.8)); 
%directedParticle = find(ma.loglogfit.alpha>1.2);
numDirected = length(directedParticle);

%Count number of brownian particles
brownianParticle = find(and(and(ma.loglogfit.alpha>0.9, ma.loglogfit.alpha<1.1),ma.loglogfit.r2fit>0.8));
%brownianParticle = find(and(ma.loglogfit.alpha>0.9,ma.loglogfit.alpha<1.1));
numBrownian = length(brownianParticle);

numTotal = numConfined + numDirected + numBrownian;

figure
plotTrackswMode(confinedParticle, brownianParticle, directedParticle, tracks, pixel);
saveas(gca,strcat(newFolder,'\',newFolder(5:end),'TrackswMode'));
close;


figure
plotMSDwMode(confinedParticle, directedParticle, brownianParticle, ma);
saveas(gca,strcat(newFolder,'\',newFolder(5:end),'MSDwMode'));
close;

figure,
plotloglogMSD(ma, confinedParticle, brownianParticle, directedParticle, clip_factor);
saveas(gca,strcat(newFolder,'\',newFolder(5:end),'loglogMSD'));
close;

figure,
totalParticle = [confinedParticle;brownianParticle;directedParticle];
percentage = plotpercentage(tracks, confinedParticle, brownianParticle, directedParticle);
saveas(gca,strcat(newFolder,'\',newFolder(5:end),'percentage'));
close;

trackstat = -ones(length(tracks),4);
output = tracks;
for i = 1:length(output)
    trackstat(i,1) = i;
    output{i,1}(:,4) = output{i,1}(:,1)/2;
    output{i,1}(:,1) = i;
    output{i,1}(:,5) = size(output{i,1},1);
    trackstat(i,2) = size(output{i,1},1);
    if ismember(i,confinedParticle) == 1
            output{i,1}(:,6) = 1;
    elseif ismember(i,directedParticle) == 1
        output{i,1}(:,6) = 2;
    elseif ismember(i,brownianParticle) == 1
        output{i,1}(:,6) = 3;
    else
        output{i,1}(:,6) = 0;
    end
    trackstat(i,3) = output{i,1}(1,6);
    distance = 0;
    for distancei = 1:size(output{i,1},1)-1
        distance = distance + sqrt(power(output{i,1}(distancei+1,2)-output{i,1}(distancei,2),2)+power(output{i,1}(distancei+1,3)-output{i,1}(distancei,3),2));
    end
    trackstat(i,4) = distance;
end

nutshell = [];
for nuti = 1:length(output)
    nutshell = [nutshell;output{nuti,1}];
end

NUT = table(nutshell);
nutname = strcat(newFolder,'\',newFolder(5:end),'SPOTS.xlsx');
writetable(NUT,nutname,'Range','A1');
txt = {'trackID','x(um)','y(um)','frame','totalframe','classification(1confine;2direct;3brown)'};
xlswrite(nutname,txt,'A1:F1');

STAT = table(trackstat);
statname = strcat(newFolder,'\',newFolder(5:end),'TRACKSTAT.xlsx');
writetable(STAT,statname,'Range','A1');
txt = {'trackID','totalframe','classification(1confine;2direct;3brown)','distance'};
xlswrite(statname,txt,'A1:D1');
end

