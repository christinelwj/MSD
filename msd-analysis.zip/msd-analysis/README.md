# MSD analysis

MSD analysis (matlab)

To do MSD analysis, please put your tracking files (.xml or .csv) in the MSD folder and run the dirfile.m following the command in command window. After running, an excel called msd.xlsx will be automaticly generated with all the msd results. 
Make sure you do NOT open the msd.xlsx when trying to run new analyses, otherwise it will fail to write it.
When two samples show exactly the same data, it is most likely that you did not reboot icy software before the second tracking. You may run tracking again or rewrite the data loading part.
If you find weird pattern in the MSD-associated diagram, e.g. extremely straight line or extremely sharp zigzag, it might be caused by misconfiguration of num_frame variable in the msd.m file. Please make sure it exceeds the total frame number of the video. However, if it is too large, the data may exceed your memory size and cause error.