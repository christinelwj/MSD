% Please put your tracking file(.xml or .csv) into the MSD folder and then
% run this file and follow the command in command window

close all; clearvars;
totalThresh = 20; %frame
folder = 'MSD\';
%folder = uigetdir;
prompt = 'Are you analyzing xml(ICY) or csv(FIJI)? Type 0 for xml or 1 for csv:';
format = input(prompt);
switch format
    case 0
        D = dir(strcat(folder,'*.xml'));
    case 1
        D = dir(strcat(folder,'*.csv'));
    otherwise
        error('Cannot recognize your answer.');
end

list = cell(length(D),1);
for i = 1:length(D)
    list(i,1) = cellstr(D(i).name);
end

xlsname = strcat(folder,'msd.xlsx');
if exist(xlsname,'file')
    delete(xlsname)
end

content = zeros(length(D),7);
T = table(list,content);
writetable(T,xlsname,'Range','B2');

switch format
    case 0
        for i = 1:length(D)
            file = strcat(folder,D(i).name);
            newFolder = file(1:end-4);
            data = loadxml(file);
            mkdir(newFolder);
            percentage = msd(data,newFolder);
            content(i,:) = percentage;
            xlswrite(xlsname,percentage,strcat('C',num2str(i+2),':E',num2str(i+2),'2'));
        end
    case 1
        for i = 1:length(D)
            file = strcat(folder,D(i).name);
            spots = xlsread(file);
            spots(isnan(spots(:,2)),:) = [];
            spots = sortrows(spots,2);
            newFolder = file(1:end-4);
            data = spots(:,[2 8 4 5]);
            mkdir(newFolder);
            data(data(:,2)>totalThresh,:) = [];
            percentage = msd(data,newFolder);
            traj = trajstat(data);
            content(i,:) = [percentage,traj];
            xlswrite(xlsname,content(i,:),strcat('C',num2str(i+2),':I',num2str(i+2)))
        end
            
end

title = {'confine','direct','brown','displacement','distance','duration','NumTracks'};
xlswrite(xlsname,title,'C2:I2');
